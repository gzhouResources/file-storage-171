module.exports = require('./flvExtend.js').default;
